<!DOCTYPE html>
<html>
<head>

		<link href="<?php echo base_url('css/bootstrap.css'); ?>" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/fullcalendar.min.css');?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/fullcalendar.min.css');?>">
		

		<script type="text/javascript" src="<?php echo base_url('js/jquery.min.js');?>"></script>

	<title><?php echo $page_title; ?></title>
</head>
<body>

