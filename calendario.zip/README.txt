CalendarIO / Tasker

- A very simple calendar where you can add , edit  and delete  a task in the calendar.it uses fullcalendar from fullcalendar.io , twitter bootstrap and of course CodeIgniter .

Developed by: NOVI
facebook.com/novhz.emo94

THANKS
Fullcalendar.io
TwitterBootstrap
CodeIgniter
Jquery,Ajax,MySQL etc..